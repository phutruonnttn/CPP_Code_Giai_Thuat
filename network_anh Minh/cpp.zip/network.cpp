#include "network.h"
#include <bits/stdc++.h>
using namespace std;

 
void findRoute (int n, int a, int b) {
  //do something
}
