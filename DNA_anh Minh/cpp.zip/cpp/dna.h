#pragma once

#include <string>

std::string analyse(int n, int t);

// Library method:

bool make_test(std::string p);

