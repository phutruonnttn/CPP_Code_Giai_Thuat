#include "dna.h"

#include <cstdlib>

std::string analyse(int n, int t) {
    make_test("0");
    return "0";
}                       